let savedSelector = null;
let savedArea = null;
let isPickingBtn = false;
let isPickingArea = false;

// 1. أداة استخراج مسار الزر (Selector)
document.addEventListener('mouseover', (e) => {
    if (!isPickingBtn) return;
    e.target.style.outline = "3px solid #3b82f6";
});

document.addEventListener('mouseout', (e) => {
    if (!isPickingBtn) return;
    e.target.style.outline = "";
});

document.addEventListener('click', (e) => {
    if (isPickingBtn) {
        e.preventDefault();
        e.stopPropagation();
        e.target.style.outline = "";
        isPickingBtn = false;
        
        // استخراج المسار الفريد للزر
        savedSelector = getUniqueSelector(e.target);
        alert('✅ تم حفظ الزر بنجاح!');
    }
}, true);

// 2. أداة رسم منطقة التصوير
let overlay, cropBox, startX, startY;
function startAreaPicker() {
    isPickingArea = true;
    overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:999999; cursor:crosshair;";
    document.body.appendChild(overlay);

    cropBox = document.createElement('div');
    cropBox.style.cssText = "position:absolute; border:2px dashed #22c55e; background:rgba(34, 197, 94, 0.2); pointer-events:none;";
    overlay.appendChild(cropBox);

    overlay.addEventListener('mousedown', (e) => {
        startX = e.clientX; startY = e.clientY;
        cropBox.style.left = startX + 'px';
        cropBox.style.top = startY + 'px';
        cropBox.style.width = '0px'; cropBox.style.height = '0px';
    });

    overlay.addEventListener('mousemove', (e) => {
        if (startX === undefined) return;
        let w = e.clientX - startX;
        let h = e.clientY - startY;
        cropBox.style.width = Math.abs(w) + 'px';
        cropBox.style.height = Math.abs(h) + 'px';
        cropBox.style.left = (w < 0 ? e.clientX : startX) + 'px';
        cropBox.style.top = (h < 0 ? e.clientY : startY) + 'px';
    });

    overlay.addEventListener('mouseup', (e) => {
        savedArea = {
            x: parseInt(cropBox.style.left), y: parseInt(cropBox.style.top),
            w: parseInt(cropBox.style.width), h: parseInt(cropBox.style.height)
        };
        document.body.removeChild(overlay);
        isPickingArea = false;
        startX = undefined;
        alert('📸 تم حفظ منطقة التصوير بنجاح!');
    });
}

// 3. استقبال الأوامر من البوب أب
let isRunning = false; // متغير للتحكم في الإيقاف والتشغيل

// 3. استقبال الأوامر من البوب أب
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "START_PICK_BUTTON") isPickingBtn = true;
    if (request.action === "START_PICK_AREA") startAreaPicker();
    
    if (request.action === "STOP_AUTOMATION") {
        isRunning = false; // أمر التوقف الفوري
    }
    
    if (request.action === "START_AUTOMATION") {
        if (!savedSelector || !savedArea) {
            alert('⚠️ الرجاء تحديد الزر ومنطقة التصوير أولاً!');
            return;
        }
        isRunning = true;
        runAutomation(request.loops, request.minDelay, request.maxDelay);
    }
});

// 4. حلقة الأتمتة الأساسية (التصوير، الضغط، الانتظار العشوائي)
async function runAutomation(loops, minDelay, maxDelay) {
    for (let i = 1; i <= loops; i++) {
        // فحص الإيقاف في بداية كل دورة
        if (!isRunning) {
            console.log('🛑 تم إيقاف العملية من قبل المستخدم.');
            alert('🛑 تم إيقاف الأتمتة بنجاح!');
            break;
        }

        console.log(`🚀 تنفيذ الدورة رقم: ${i}`);
        
        // أ. طلب التقاط الشاشة
        const dataUrl = await new Promise(res => chrome.runtime.sendMessage({ action: "TAKE_SCREENSHOT" }, res));
        
        // ب. قص الصورة 
        const croppedUrl = await cropImage(dataUrl, savedArea);
        
        // ج. تحميل الصورة المخصوصة
        chrome.runtime.sendMessage({ action: "DOWNLOAD_IMAGE", url: croppedUrl, filename: `Capture_${i.toString().padStart(3, '0')}.png` });

        // د. النقر على الزر برمجياً
        const btn = document.querySelector(savedSelector);
        if (btn) btn.click();
        else console.warn('⚠️ لم يتم العثور على الزر في هذه الصفحة!');

        // هـ. حساب الانتظار العشوائي (بين الحد الأدنى والأقصى)
        const randomDelaySec = (Math.random() * (maxDelay - minDelay)) + minDelay;
        console.log(`⏳ انتظار عشوائي لمدة ${randomDelaySec.toFixed(2)} ثانية...`);
        
        // و. الانتظار للصفحة التالية
        await new Promise(r => setTimeout(r, randomDelaySec * 1000));
    }
    
    if (isRunning) {
        alert('🎉 انتهت عملية الأتمتة والتصوير بنجاح!');
        isRunning = false;
    }
}

// ================= الدوال المساعدة =================
function getUniqueSelector(el) {
    if (el.id) return `#${el.id}`;
    let path = [];
    while (el.nodeType === Node.ELEMENT_NODE) {
        let selector = el.nodeName.toLowerCase();
        if (el.id) { path.unshift(`#${el.id}`); break; }
        else {
            let sib = el, nth = 1;
            while (sib = sib.previousElementSibling) if (sib.nodeName.toLowerCase() == selector) nth++;
            if (nth != 1) selector += `:nth-of-type(${nth})`;
        }
        path.unshift(selector);
        el = el.parentNode;
    }
    return path.join(" > ");
}

function cropImage(dataUrl, area) {
    return new Promise((resolve) => {
        let img = new Image();
        img.onload = () => {
            let canvas = document.createElement('canvas');
            canvas.width = area.w; canvas.height = area.h;
            let ctx = canvas.getContext('2d');
            // استخراج كثافة البكسلات (DPI Awareness) لقص دقيق للشاشات الحديثة
            let dpr = window.devicePixelRatio || 1;
            ctx.drawImage(img, area.x * dpr, area.y * dpr, area.w * dpr, area.h * dpr, 0, 0, area.w, area.h);
            resolve(canvas.toDataURL('image/png'));
        };
        img.src = dataUrl;
    });
}