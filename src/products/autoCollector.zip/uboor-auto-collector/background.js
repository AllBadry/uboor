chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "TAKE_SCREENSHOT") {
        // التقاط التاب المفتوح حالياً
        chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
            sendResponse(dataUrl);
        });
        return true; // إبقاء قناة الاتصال مفتوحة للـ Asynchronous
    }
    
    if (request.action === "DOWNLOAD_IMAGE") {
        // تحميل الصورة بدون إظهار نافذة "حفظ باسم"
        chrome.downloads.download({
            url: request.url,
            filename: `Uboor_Auto_Capture/${request.filename}`,
            saveAs: false
        });
    }
});