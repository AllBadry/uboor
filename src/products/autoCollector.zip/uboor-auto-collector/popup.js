document.getElementById('pickBtn').addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: "START_PICK_BUTTON" });
    window.close();
});

document.getElementById('pickArea').addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: "START_PICK_AREA" });
    window.close();
});

// زر البدء
document.getElementById('startAuto').addEventListener('click', async () => {
    const loops = document.getElementById('loops').value;
    const minDelay = document.getElementById('minDelay').value;
    const maxDelay = document.getElementById('maxDelay').value;
    
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { 
        action: "START_AUTOMATION", 
        loops: parseInt(loops), 
        minDelay: parseFloat(minDelay),
        maxDelay: parseFloat(maxDelay)
    });

    // تغيير شكل الأزرار
    document.getElementById('startAuto').style.display = 'none';
    document.getElementById('stopAuto').style.display = 'block';
    document.getElementById('status').innerText = "جاري العمل... يمكنك إيقافها في أي وقت!";
    document.getElementById('status').style.color = "#22c55e";
});

// زر الإيقاف
document.getElementById('stopAuto').addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: "STOP_AUTOMATION" });

    // إعادة شكل الأزرار
    document.getElementById('startAuto').style.display = 'block';
    document.getElementById('stopAuto').style.display = 'none';
    document.getElementById('status').innerText = "تم إيقاف الأداة برغبة المستخدم.";
    document.getElementById('status').style.color = "#ef4444";
});