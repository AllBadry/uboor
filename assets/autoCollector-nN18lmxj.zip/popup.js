// دالة مساعدة لإرسال الرسائل بشكل آمن والتعامل مع الأخطاء
async function safeSendMessage(message, onSuccess, onFailure) {
    try {
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (!tab) return;

        // منع التشغيل على صفحات المتصفح الداخلية (حيث لا يمكن حقن content.js)
        if (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("about:")) {
            updateStatus("⚠️ لا يمكن تشغيل الإضافة على صفحات المتصفح الداخلية.", "#ef4444");
            if (onFailure) onFailure();
            return;
        }

        // إرسال الرسالة وانتظار الرد الإيجابي
        await chrome.tabs.sendMessage(tab.id, message);
        if (onSuccess) onSuccess();

    } catch (error) {
        // التعامل مع خطأ عدم وجود مستقبل (الـ content.js غير محقون أو الصفحة تحتاج تحديث)
        console.warn("فشل الاتصال بالصفحة:", error);
        updateStatus("⚠️ يرجى تحديث (Refresh) الصفحة الحالية لتفعيل الأداة!", "#ef4444");
        if (onFailure) onFailure();
    }
}

// دالة مساعدة لتحديث نص الحالة بسهولة
function updateStatus(text, color) {
    const statusEl = document.getElementById('status');
    if (statusEl) {
        statusEl.innerText = text;
        statusEl.style.color = color;
    }
}

// 1. زر اختيار الزر
document.getElementById('pickBtn').addEventListener('click', async () => {
    await safeSendMessage({ action: "START_PICK_BUTTON" }, () => {
        // تأخير بسيط جداً لضمان وصول الرسالة قبل إغلاق الـ popup
        setTimeout(() => window.close(), 100);
    });
});

// 2. زر اختيار منطقة التصوير
document.getElementById('pickArea').addEventListener('click', async () => {
    await safeSendMessage({ action: "START_PICK_AREA" }, () => {
        setTimeout(() => window.close(), 100);
    });
});

// 3. زر البدء بالأتمتة
document.getElementById('startAuto').addEventListener('click', async () => {
    const loops = document.getElementById('loops').value;
    const minDelay = document.getElementById('minDelay').value;
    const maxDelay = document.getElementById('maxDelay').value;
    
    const messageData = { 
        action: "START_AUTOMATION", 
        loops: parseInt(loops) || 10, 
        minDelay: parseFloat(minDelay) || 2,
        maxDelay: parseFloat(maxDelay) || 5
    };

    // لن تتغير واجهة المستخدم إلا إذا تم إرسال الأمر بنجاح للمتصفح
    await safeSendMessage(messageData, () => {
        document.getElementById('startAuto').style.display = 'none';
        document.getElementById('stopAuto').style.display = 'block';
        updateStatus("جاري العمل... يمكنك إيقافها في أي وقت!", "#22c55e");
    });
});

// 4. زر الإيقاف الفوري
document.getElementById('stopAuto').addEventListener('click', async () => {
    await safeSendMessage({ action: "STOP_AUTOMATION" });

    // نعيد شكل الأزرار للحالة الطبيعية في كل الأحوال
    document.getElementById('startAuto').style.display = 'block';
    document.getElementById('stopAuto').style.display = 'none';
    updateStatus("تم إيقاف الأداة برغبة المستخدم.", "#ef4444");
});