// content.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "runFullAudit") {
    (async () => {
      const currentUrl = new URL(window.location.href);
      
      const report = {
        // --- الميزات الأساسية القديمة ---
        linksData: analyzeAllLinks(currentUrl.hostname),
        contentData: analyzeContentAndKeywords(),
        openGraph: getOpenGraphData(),
        imagesData: analyzeImagesPerformance(),
        standardTags: getStandardTags(),
        sitemap: await checkSitemap(currentUrl.origin),
        
        // --- الميزات المتقدمة السابقة ---
        schemaData: extractSchemaData(),
        techStack: detectTechnologies(),
        coreWebVitals: await measureCoreWebVitals(),
        serpAndSocial: getSerpAndSocialPreview(),
        indexability: await checkIndexability(currentUrl),
        textAnalysis: analyzeTextContentAdvanced(),
        hreflangData: validateHreflang(),
        securityHeaders: await checkSecurityHeaders(currentUrl.href),

        // --- الميزة الجديدة: فحص إمكانية الوصول (Accessibility - a11y) ---
        accessibility: analyzeAccessibility()
      };

      sendResponse(report); // نرسل التقرير الأولي للواجهة
      
      // بدء عملية الزحف الداخلي في الخلفية
      startClientSideCrawler(report.linksData.internalLinks, currentUrl.origin);
      
    })();
    return true; // إبقاء قناة الاتصال مفتوحة
  }
});

// ==========================================
// 1. فحص إمكانية الوصول (Accessibility)
// ==========================================
function analyzeAccessibility() {
  let a11yReport = {
    ariaTagsCount: 0,
    tapTargetIssues: 0,
    colorContrastIssues: 0, 
    issues: []
  };

  // 1. فحص وسوم ARIA
  const ariaElements = document.querySelectorAll('[aria-label], [aria-hidden], [role]');
  a11yReport.ariaTagsCount = ariaElements.length;
  if (a11yReport.ariaTagsCount === 0) {
    a11yReport.issues.push("⚠️ لم يتم العثور على أي وسوم ARIA. استخدامها يحسن تجربة ذوي الهمم.");
  }

  // 2. فحص حجم أزرار اللمس (Tap Targets)
  const clickableElements = document.querySelectorAll('a, button, input[type="button"], input[type="submit"]');
  clickableElements.forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
        if (rect.width < 44 || rect.height < 44) {
            a11yReport.tapTargetIssues++;
        }
    }
  });

  if (a11yReport.tapTargetIssues > 0) {
      a11yReport.issues.push(`⚠️ تم العثور على ${a11yReport.tapTargetIssues} عنصر(اً) قابلاً للنقر بحجم صغير جداً (أقل من 44x44px). هذا يضر بتجربة المستخدم على الجوال.`);
  }

  // 3. فحص التباين اللوني (مبسط)
  const bodyStyles = window.getComputedStyle(document.body);
  const bgColor = bodyStyles.backgroundColor;
  const textColor = bodyStyles.color;
  
  const getLuminance = (rgbString) => {
      const match = rgbString.match(/\d+/g);
      if(!match) return 1;
      const r = parseInt(match[0]);
      const g = parseInt(match[1]);
      const b = parseInt(match[2]);
      return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  };

  const bgLum = getLuminance(bgColor);
  const textLum = getLuminance(textColor);
  const contrastRatio = (Math.max(bgLum, textLum) + 0.05) / (Math.min(bgLum, textLum) + 0.05);

  if (contrastRatio < 3) {
      a11yReport.colorContrastIssues++;
      a11yReport.issues.push(`⚠️ التباين اللوني العام للصفحة يبدو ضعيفاً (النسبة: ${contrastRatio.toFixed(1)}:1). تأكد من وضوح النص للقراءة.`);
  }

  return a11yReport;
}

// ==========================================
// 2. فحص الأمان ورؤوس الاستجابة (HTTP Headers)
// ==========================================
async function checkSecurityHeaders(url) {
  let headersReport = {
    hsts: { exists: false, value: "مفقود (غير آمن)", description: "HTTP Strict Transport Security (HSTS) يجبر المتصفحات على استخدام اتصال آمن HTTPS فقط." },
    xFrameOptions: { exists: false, value: "مفقود (عرضة لهجمات Clickjacking)", description: "X-Frame-Options يمنع المواقع الأخرى من تضمين صفحتك داخل iframe مما يحميك ويحسن موثوقية السيو." },
    cacheControl: { exists: false, value: "غير محدد", description: "Cache-Control يحدد كيفية تخزين الصفحة مؤقتًا، مما يؤثر بشكل مباشر على سرعة التحميل." },
    server: { exists: false, value: "مخفي (جيد أمنياً)", description: "الكشف عن نوع السيرفر قد يسهل استغلال الثغرات." },
    issuesCount: 0
  };

  try {
    const response = await fetch(url, { method: 'HEAD' });
    
    const hstsHeader = response.headers.get('Strict-Transport-Security');
    if (hstsHeader) {
      headersReport.hsts.exists = true;
      headersReport.hsts.value = "مفعل ✅";
    } else {
      headersReport.issuesCount++;
    }

    const xFrameHeader = response.headers.get('X-Frame-Options');
    if (xFrameHeader) {
      headersReport.xFrameOptions.exists = true;
      headersReport.xFrameOptions.value = `مفعل (${xFrameHeader}) ✅`;
    } else {
      headersReport.issuesCount++;
    }

    const cacheHeader = response.headers.get('Cache-Control');
    if (cacheHeader) {
      headersReport.cacheControl.exists = true;
      headersReport.cacheControl.value = cacheHeader;
    }

    const serverHeader = response.headers.get('Server');
    if (serverHeader) {
      headersReport.server.exists = true;
      headersReport.server.value = `مكشوف (${serverHeader}) ⚠️`;
    }

  } catch (error) {
    headersReport.hsts.value = "تعذر الفحص (محمي بواسطة CORS)";
    headersReport.xFrameOptions.value = "تعذر الفحص";
    headersReport.cacheControl.value = "تعذر الفحص";
  }

  return headersReport;
}

// ==========================================
// 3. فحص وسوم Hreflang
// ==========================================
function validateHreflang() {
  const hreflangTags = document.querySelectorAll('link[rel="alternate"][hreflang]');
  let hreflangList = [];
  let issues = [];
  let hasXDefault = false;
  let hasSelfReference = false;
  const currentUrl = window.location.href.split('#')[0].split('?')[0];

  if (hreflangTags.length === 0) {
    return { 
      exists: false, 
      tags: [], 
      issues: ["لا توجد وسوم hreflang في هذه الصفحة."] 
    };
  }

  hreflangTags.forEach(tag => {
    const lang = tag.getAttribute('hreflang').toLowerCase();
    const href = tag.getAttribute('href');
    
    hreflangList.push({ lang: lang, url: href });

    if (lang === 'x-default') {
      hasXDefault = true;
    }

    if (href === currentUrl || href === window.location.href) {
      hasSelfReference = true;
    }

    const langFormatValid = /^[a-z]{2,3}(-[a-z]{2,4})?$/i.test(lang) || lang === 'x-default';
    if (!langFormatValid) {
      issues.push(`صيغة كود اللغة غير صالحة: "${lang}" للرابط ${href}`);
    }
  });

  if (!hasXDefault) {
    issues.push("⚠️ مفقود: كود اللغة الافتراضي (x-default) غير موجود. يوصى به لتوجيه الزوار الذين لا تتطابق لغاتهم.");
  }

  if (!hasSelfReference) {
    issues.push("⚠️ مفقود: الرابط المرجعي الذاتي (Self-referencing hreflang) مفقود. يجب أن تشير الصفحة لنفسها ضمن وسوم اللغات.");
  }

  return { 
    exists: true, 
    totalTags: hreflangTags.length, 
    tags: hreflangList, 
    issues: issues 
  };
}

// ==========================================
// 4. تحليل النص المتقدم (NLP & Intent)
// ==========================================
function analyzeTextContentAdvanced() {
  const htmlLength = document.body.innerHTML.length;
  
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
  let textNodes = [];
  let node;
  while(node = walker.nextNode()) {
      if (node.parentElement.tagName !== 'SCRIPT' && node.parentElement.tagName !== 'STYLE') {
          textNodes.push(node.nodeValue);
      }
  }
  const cleanText = textNodes.join(' ').replace(/\s+/g, ' ').trim();
  const textLength = cleanText.length;
  
  const ratio = htmlLength > 0 ? ((textLength / htmlLength) * 100).toFixed(2) : 0;
  
  const words = cleanText.split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const readingTime = Math.ceil(wordCount / 200); 
  
  const sentences = cleanText.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const sentenceCount = sentences.length > 0 ? sentences.length : 1;
  const avgWordsPerSentence = (wordCount / sentenceCount).toFixed(1);
  
  let readability = "متوسطة";
  if (avgWordsPerSentence > 20) readability = "صعبة (جمل طويلة جدًا)";
  else if (avgWordsPerSentence < 10) readability = "سهلة جدًا";

  let intentScores = { 
    informational: 0, 
    transactional: 0, 
    navigational: 0 
  };
  
  const infoKeywords = ['كيف', 'لماذا', 'ما', 'معلومات', 'دليل', 'طريقة', 'تعلم', 'أسباب', 'أنواع', 'شرح'];
  const transKeywords = ['شراء', 'سعر', 'خصم', 'عروض', 'تخفيض', 'متجر', 'سلة', 'طلب', 'رخيص', 'احجز'];
  const navKeywords = ['دخول', 'تسجيل', 'تواصل', 'عنا', 'اتصل', 'فروع', 'حسابي', 'تسجيل الدخول'];

  const lowerText = cleanText.toLowerCase();

  infoKeywords.forEach(kw => { if (lowerText.includes(kw)) intentScores.informational++; });
  transKeywords.forEach(kw => { if (lowerText.includes(kw)) intentScores.transactional++; });
  navKeywords.forEach(kw => { if (lowerText.includes(kw)) intentScores.navigational++; });

  let primaryIntent = "غير واضح";
  let maxScore = 0;
  for (const [intent, score] of Object.entries(intentScores)) {
      if (score > maxScore) {
          maxScore = score;
          if (intent === 'informational') primaryIntent = "معلوماتي 📚";
          if (intent === 'transactional') primaryIntent = "بيعي / تجاري 🛒";
          if (intent === 'navigational') primaryIntent = "تنقلي / إداري 🧭";
      }
  }

  const stopWords = ['في', 'من', 'على', 'إلى', 'أن', 'هذا', 'عن', 'مع', 'هل', 'لا', 'ما', 'و', 'أو', 'ثم', 'لكن', 'التي', 'الذي'];
  let termFrequency = {};
  
  words.forEach(w => {
      let cleanWord = w.toLowerCase().replace(/[^\w\u0600-\u06FF]/g, '');
      if (cleanWord.length > 3 && !stopWords.includes(cleanWord)) {
          termFrequency[cleanWord] = (termFrequency[cleanWord] || 0) + 1;
      }
  });

  const topTFKeywords = Object.entries(termFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(entry => entry[0]);

  return { 
    ratio: `${ratio}%`, 
    readingTime: `${readingTime} دقائق`, 
    wordCount: wordCount, 
    sentenceCount: sentenceCount, 
    avgWordsPerSentence: avgWordsPerSentence, 
    readability: readability, 
    primaryIntent: primaryIntent, 
    topKeywords: topTFKeywords 
  };
}

// ==========================================
// 5. محاكي SERP والسوشيال ميديا
// ==========================================
function getSerpAndSocialPreview() {
  const getMeta = (name, attribute = "name") => {
    const tag = document.querySelector(`meta[${attribute}="${name}"]`);
    return tag ? tag.content.trim() : "";
  };

  const title = document.title || getMeta("og:title", "property") || "";
  const description = getMeta("description") || getMeta("og:description", "property") || "";
  
  let favicon = "";
  const iconTag = document.querySelector('link[rel="icon"], link[rel="shortcut icon"], link[rel="icon"][type="image/x-icon"]');
  if (iconTag) { 
    favicon = iconTag.href; 
  } else { 
    favicon = window.location.origin + "/favicon.ico"; 
  }

  return {
    googleSerp: { 
      title: title, 
      titleLength: title.length, 
      titleWarning: title.length > 60 ? "⚠️ العنوان طويل (سيتم قصه في جوجل)" : (title.length < 30 ? "⚠️ العنوان قصير جداً" : "✅ طول مثالي"), 
      url: window.location.href, 
      description: description, 
      descriptionLength: description.length, 
      descriptionWarning: description.length > 160 ? "⚠️ الوصف طويل (سيتم قصه)" : (description.length < 50 ? "⚠️ الوصف قصير" : "✅ طول مثالي"), 
      favicon: favicon 
    },
    facebook: { 
      title: getMeta("og:title", "property") || title, 
      description: getMeta("og:description", "property") || description, 
      image: getMeta("og:image", "property") || "", 
      siteName: getMeta("og:site_name", "property") || "" 
    },
    twitter: { 
      card: getMeta("twitter:card") || "summary_large_image", 
      title: getMeta("twitter:title") || getMeta("og:title", "property") || title, 
      description: getMeta("twitter:description") || getMeta("og:description", "property") || description, 
      image: getMeta("twitter:image") || getMeta("og:image", "property") || "" 
    }
  };
}

// ==========================================
// 6. تحليل الأرشفة وملف Robots
// ==========================================
async function checkIndexability(urlObj) {
  let indexability = { 
    metaRobots: "غير موجود", 
    xRobotsTag: "غير موجود", 
    robotsTxtStatus: "جاري الفحص...", 
    isIndexable: true, 
    issues: [] 
  };

  const metaRobotsTag = document.querySelector('meta[name="robots"], meta[name="googlebot"]');
  if (metaRobotsTag) {
    indexability.metaRobots = metaRobotsTag.content.toLowerCase();
    if (indexability.metaRobots.includes("noindex")) { 
      indexability.isIndexable = false; 
      indexability.issues.push("علامة Meta Robots تمنع الأرشفة (noindex)"); 
    }
  }

  try {
    const response = await fetch(urlObj.href, { method: 'HEAD' });
    const xRobots = response.headers.get('X-Robots-Tag');
    if (xRobots) {
      indexability.xRobotsTag = xRobots.toLowerCase();
      if (indexability.xRobotsTag.includes("noindex")) { 
        indexability.isIndexable = false; 
        indexability.issues.push("السيرفر يمنع الأرشفة عبر ترويسة (X-Robots-Tag: noindex)"); 
      }
    }
  } catch (e) { 
    indexability.xRobotsTag = "تعذر الفحص"; 
  }

  try {
    const robotsRes = await fetch(`${urlObj.origin}/robots.txt`);
    if (robotsRes.ok) {
      const text = await robotsRes.text();
      const lines = text.split('\n');
      let isGooglebotOrAll = false; 
      let isDisallowed = false;

      for (let line of lines) {
        line = line.trim().toLowerCase();
        if (line.startsWith('user-agent:')) { 
          const agent = line.split(':')[1].trim(); 
          isGooglebotOrAll = (agent === '*' || agent === 'googlebot'); 
        } 
        else if (isGooglebotOrAll && line.startsWith('disallow:')) { 
          const rule = line.split(':')[1].trim(); 
          if (rule === '/' || (rule.length > 1 && urlObj.pathname.startsWith(rule))) { 
            isDisallowed = true; 
          } 
        }
      }

      if (isDisallowed) { 
        indexability.robotsTxtStatus = "🚫 محظور (Disallowed)"; 
        indexability.isIndexable = false; 
        indexability.issues.push("الصفحة محظورة من الزحف في ملف robots.txt"); 
      } 
      else { 
        indexability.robotsTxtStatus = "✅ مسموح (Allowed)"; 
      }
    } else { 
      indexability.robotsTxtStatus = "⚠️ لا يوجد ملف robots.txt (مسموح افتراضياً)"; 
    }
  } catch (e) { 
    indexability.robotsTxtStatus = "تعذر فحص robots.txt"; 
  }

  return indexability;
}

// ==========================================
// 7. استخراج البيانات المنظمة (Schema)
// ==========================================
function extractSchemaData() {
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  let schemas = [];
  scripts.forEach(script => {
    try {
      const parsed = JSON.parse(script.innerText);
      schemas.push(parsed);
    } catch(e) {
      // تجاهل الأكواد المكسورة
    }
  });
  return schemas;
}

// ==========================================
// 8. اكتشاف التقنيات (Technologies)
// ==========================================
function detectTechnologies() {
  let tech = [];
  const html = document.documentElement.outerHTML.toLowerCase();
  
  if (html.includes('wp-content')) tech.push('WordPress');
  if (window.Shopify) tech.push('Shopify');
  if (window.__NEXT_DATA__) tech.push('Next.js');
  if (html.includes('gtm.js') || window.dataLayer) tech.push('Google Tag Manager');
  if (window.fbq || html.includes('fbevents.js')) tech.push('Meta/Facebook Pixel');
  
  return tech.length > 0 ? tech : ['غير معروف / برمجة خاصة'];
}

// ==========================================
// 9. قياس أداء جوجل (Core Web Vitals)
// ==========================================
async function measureCoreWebVitals() {
  let metrics = { lcp: "جاري الحساب...", cls: "0.000" };
  
  try {
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      const lastEntry = entries[entries.length - 1];
      metrics.lcp = (lastEntry.renderTime || lastEntry.loadTime).toFixed(0) + " ms";
    }).observe({type: 'largest-contentful-paint', buffered: true});

    new PerformanceObserver((entryList) => {
      let clsValue = 0;
      for (const entry of entryList.getEntries()) {
        if (!entry.hadRecentInput) clsValue += entry.value;
      }
      metrics.cls = clsValue.toFixed(3);
    }).observe({type: 'layout-shift', buffered: true});
    
  } catch (e) {
    metrics = { lcp: "غير مدعوم", cls: "غير مدعوم" };
  }
  
  await new Promise(resolve => setTimeout(resolve, 500));
  return metrics;
}

// ==========================================
// 10. تحليل جميع الروابط (الداخلية والخارجية)
// ==========================================
function analyzeAllLinks(currentHostname) {
  const links = Array.from(document.querySelectorAll('a'));
  let internalLinks = new Set();
  let subdomains = new Set();
  let externalLinks = new Set();

  links.forEach(a => {
    try {
      if (!a.href || a.href.startsWith('javascript') || a.href.startsWith('mailto')) return;
      const url = new URL(a.href);
      
      if (url.hostname === currentHostname) {
        internalLinks.add(url.href);
      } else if (url.hostname.endsWith(currentHostname)) {
        subdomains.add(url.hostname); 
      } else {
        externalLinks.add(url.href);
      }
    } catch (e) {}
  });

  return {
    internalLinks: Array.from(internalLinks),
    subdomains: Array.from(subdomains),
    externalLinks: Array.from(externalLinks)
  };
}

// ==========================================
// 11. تحليل العناوين وكثافة الكلمات
// ==========================================
function analyzeContentAndKeywords() {
  const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map(h => ({
    tag: h.tagName,
    text: h.innerText.trim()
  }));

  const text = document.body.innerText.toLowerCase().replace(/[^\w\s\u0600-\u06FF]/g, '');
  const words = text.split(/\s+/).filter(w => w.length > 2);
  const stopWords = ['the', 'and', 'for', 'في', 'من', 'على', 'إلى', 'أن', 'هذا']; 
  
  let density = {};
  words.forEach(w => {
    if (!stopWords.includes(w)) density[w] = (density[w] || 0) + 1;
  });
  
  const topKeywords = Object.entries(density)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10); 

  return { tree: headings, keywordDensity: topKeywords };
}

// ==========================================
// 12. تحليل Open Graph الأساسي
// ==========================================
function getOpenGraphData() {
  const getMeta = (prop) => document.querySelector(`meta[property="${prop}"]`)?.content;
  return {
    ogTitle: getMeta("og:title"),
    ogDescription: getMeta("og:description"),
    ogImage: getMeta("og:image"),
    twitterCard: document.querySelector(`meta[name="twitter:card"]`)?.content
  };
}

// ==========================================
// 13. تحليل أداء وأحجام الصور
// ==========================================
function analyzeImagesPerformance() {
  const images = document.querySelectorAll('img');
  let issues = [];

  images.forEach(img => {
    let issue = { src: img.src, alt: img.alt || "مفقود" };
    
    if (img.naturalWidth > img.clientWidth * 2) {
      issue.sizeWarning = `صورة ضخمة (${img.naturalWidth}px) معروضة بحجم صغير (${img.clientWidth}px)`;
    }

    const performanceEntries = performance.getEntriesByName(img.src);
    if (performanceEntries.length > 0) {
      const entry = performanceEntries[0];
      const loadTimeMs = entry.responseEnd - entry.startTime;
      const sizeKB = (entry.encodedBodySize / 1024).toFixed(1); 
      
      issue.loadTime = loadTimeMs.toFixed(0) + "ms";
      if (sizeKB > 0) issue.fileSize = sizeKB + " KB";
      
      if (loadTimeMs > 1000) issue.speedWarning = "تحميل بطيء جداً";
      if (sizeKB > 500) issue.heavyWarning = "حجم الملف كبير ويؤثر على السيو";
    }

    if (!img.alt || issue.sizeWarning || issue.speedWarning || issue.heavyWarning) {
      issues.push(issue);
    }
  });

  return { total: images.length, issuesCount: issues.length, detailedIssues: issues };
}

// ==========================================
// 14. تحليل الوسوم القياسية الأساسية
// ==========================================
function getStandardTags() {
  return {
    canonical: document.querySelector('link[rel="canonical"]')?.href || "مفقود",
    title: document.title,
    metaDescription: document.querySelector('meta[name="description"]')?.content || "مفقود",
    viewport: document.querySelector('meta[name="viewport"]')?.content || "مفقود",
    lang: document.documentElement.lang || "مفقود"
  };
}

// ==========================================
// 15. فحص خريطة الموقع
// ==========================================
async function checkSitemap(origin) {
  try {
    const res = await fetch(`${origin}/sitemap.xml`, { method: 'HEAD' });
    return res.ok ? "✅ خريطة الموقع موجودة" : "❌ غير موجودة في المسار الافتراضي";
  } catch (e) {
    return "⚠️ تعذر الفحص (CORS أو محظور)";
  }
}

// ==========================================
// 16. الكراولر الداخلي وفاحص الروابط المكسورة
// ==========================================
async function startClientSideCrawler(internalLinks, origin) {
  console.log("🚀 بدء الزحف الداخلي...");
  let queue = [...internalLinks].slice(0, 50); 
  let visited = new Set();
  let brokenLinks = [];

  for (let url of queue) {
    if (visited.has(url)) continue;
    visited.add(url);

    try {
      const response = await fetch(url, { method: 'GET' });
      if (!response.ok) {
        brokenLinks.push({ url, status: response.status });
        continue;
      }

      const htmlText = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlText, "text/html");
      
      const newLinks = Array.from(doc.querySelectorAll('a'))
                            .map(a => a.href)
                            .filter(href => href.startsWith(origin) && !visited.has(href));
                            
      queue = [...new Set([...queue, ...newLinks])].slice(0, 50); 

    } catch (error) {
      brokenLinks.push({ url, status: "Network Error / CORS" });
    }
  }

  console.log("✅ انتهى الزحف!", { visitedCount: visited.size, brokenLinks });
}