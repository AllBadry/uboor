let currentReportData = null;

document.addEventListener('DOMContentLoaded', () => {
  const loader = document.getElementById('loader');
  const resultsDiv = document.getElementById('results');
  const btnAnalyze = document.getElementById('analyzeBtn');
  const btnExport = document.getElementById('exportBtn');

  if (!btnAnalyze || !loader || !resultsDiv || !btnExport) return;

  btnAnalyze.addEventListener('click', async () => {
    loader.style.display = 'flex';
    btnAnalyze.style.display = 'none';
    btnExport.style.display = 'none';
    resultsDiv.style.display = 'none';
    
    try {
      let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      chrome.tabs.sendMessage(tab.id, { action: "runFullAudit" }, (response) => {
        if (chrome.runtime.lastError) {
           loader.innerHTML = `<div style='color:#ef4444; font-weight:bold; text-align:center;'>لا يمكن الاتصال بالصفحة.<br>حدث الصفحة (F5) وحاول مجدداً.</div>`;
           return;
        }

        if (response) {
          currentReportData = response;
          
          loader.style.display = 'none';
          btnAnalyze.style.display = 'flex';
          btnAnalyze.innerHTML = `🔄 تحديث الفحص`;
          btnExport.style.display = 'flex';
          resultsDiv.style.display = 'block';

          // =====================================
          // 1. محاكي الظهور (SERP & Social)
          // =====================================
          const serp = response.serpAndSocial;
          const currentUrlObj = new URL(serp.googleSerp.url);
          const domain = currentUrlObj.hostname;

          document.getElementById('google-preview').innerHTML = `
            <div class="g-url"><img src="${serp.googleSerp.favicon}" width="16" height="16" onerror="this.style.display='none'"> <span>${domain}</span></div>
            <h3 class="g-title">${serp.googleSerp.title || 'بدون عنوان'}</h3>
            <div class="g-desc">${serp.googleSerp.description || 'لا يوجد وصف تعريفي.'}</div>
            <div class="g-warning">📝 العنوان: ${serp.googleSerp.titleLength} حرف (${serp.googleSerp.titleWarning}) | الوصف: ${serp.googleSerp.descriptionLength} حرف (${serp.googleSerp.descriptionWarning})</div>
          `;

          const fbImageHtml = serp.facebook.image ? `<img class="soc-img" src="${serp.facebook.image}" onerror="this.style.display='none'">` : `<div class="soc-no-img">بدون صورة</div>`;
          document.getElementById('fb-preview').innerHTML = `${fbImageHtml}<div class="soc-text"><div class="soc-domain">${domain.toUpperCase()}</div><div class="soc-title">${serp.facebook.title || serp.googleSerp.title || 'بدون عنوان'}</div><div class="soc-desc">${serp.facebook.description || serp.googleSerp.description || 'بدون وصف'}</div></div>`;

          const twImageHtml = serp.twitter.image ? `<img class="soc-img" src="${serp.twitter.image}" onerror="this.style.display='none'">` : `<div class="soc-no-img">بدون صورة</div>`;
          document.getElementById('twitter-preview').innerHTML = `${twImageHtml}<div class="soc-text" style="background:#fff; border-top:1px solid #ced0d4;"><div class="soc-title">${serp.twitter.title || serp.googleSerp.title || 'بدون عنوان'}</div><div class="soc-desc">${serp.twitter.description || 'بدون وصف'}</div><div class="soc-domain" style="margin-top:5px;">🔗 ${domain}</div></div>`;

          // =====================================
          // 2. تحليل النص المتقدم (NLP)
          // =====================================
          const nlp = response.textAnalysis;
          const schemaCount = response.schemaData.length;
          let kwHtml = nlp.topKeywords.map(k => `<span class="tech-tag" style="background:#e0e7ff; border-color:#c7d2fe; color:#3730a3;">${k}</span>`).join(' ');
          document.getElementById('nlp-data').innerHTML = `
            <div class="metric-grid">
              <div class="metric-card"><div class="metric-title">نية البحث (Intent)</div><div class="metric-value" style="color:#2563eb;">${nlp.primaryIntent}</div></div>
              <div class="metric-card"><div class="metric-title">قابلية القراءة</div><div class="metric-value" style="color:${nlp.readability.includes('صعبة') ? '#ef4444' : '#10b981'};">${nlp.readability}</div></div>
              <div class="metric-card"><div class="metric-title">عدد الكلمات (نقي)</div><div class="metric-value">${nlp.wordCount} كلمة</div></div>
              <div class="metric-card"><div class="metric-title">نسبة النص للكود</div><div class="metric-value" style="color:${parseFloat(nlp.ratio) < 10 ? '#ef4444' : '#10b981'};">${nlp.ratio}</div></div>
            </div>
            <div style="margin-bottom:10px;"><strong style="font-size:12px; color:#64748b;">🔑 أهم الكلمات المفتاحية (TF-IDF):</strong><br><div style="margin-top:5px;">${kwHtml || '<span style="font-size:11px; color:#ef4444;">لم يتم اكتشاف كلمات واضحة</span>'}</div></div>
            <div><strong style="font-size:12px; color:#64748b;">📊 البيانات المنظمة (Schema):</strong> <span class="badge ${schemaCount > 0 ? 'badge-green' : ''}" style="float:none;">${schemaCount > 0 ? `موجود (${schemaCount})` : 'مفقود ⚠️'}</span></div>
          `;

          // =====================================
          // 3. الأمان وإمكانية الوصول
          // =====================================
          const sec = response.securityHeaders;
          const a11y = response.accessibility;
          const secBadge = document.getElementById('security-badge');
          const totalSecIssues = sec.issuesCount + a11y.issues.length;
          secBadge.className = totalSecIssues === 0 ? 'badge badge-green' : 'badge';
          secBadge.innerText = totalSecIssues === 0 ? 'ممتاز ✅' : `${totalSecIssues} مشاكل ⚠️`;

          let a11yIssuesHtml = a11y.issues.map(i => `<div style="color:#ef4444; font-size:11px; margin-top:4px;">${i}</div>`).join('');
          document.getElementById('security-a11y-data').innerHTML = `
            <strong style="font-size:12px; color:#64748b;">🔒 فحص الأمان (Headers):</strong>
            <div class="list-item" style="direction:rtl; margin-top:5px;"><strong style="width:100px;">HSTS:</strong> <span style="direction:ltr; flex:1; color:${sec.hsts.exists ? 'green' : 'red'}; font-weight:bold;">${sec.hsts.value}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:100px;">X-Frame:</strong> <span style="direction:ltr; flex:1; color:${sec.xFrameOptions.exists ? 'green' : 'red'}; font-weight:bold;">${sec.xFrameOptions.value}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:100px;">Cache:</strong> <span style="direction:ltr; flex:1; font-size:11px;">${sec.cacheControl.value}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:100px;">Server:</strong> <span style="direction:ltr; flex:1;">${sec.server.value}</span></div>
            <hr style="border-top:1px dashed #e2e8f0; margin:10px 0;">
            <strong style="font-size:12px; color:#64748b;">♿ إمكانية الوصول (Accessibility):</strong>
            <div class="metric-grid" style="margin-top:5px;">
              <div class="metric-card"><div class="metric-title">وسوم ARIA</div><div class="metric-value">${a11y.ariaTagsCount}</div></div>
              <div class="metric-card"><div class="metric-title">أزرار صغيرة</div><div class="metric-value" style="color:${a11y.tapTargetIssues > 0 ? '#ef4444' : '#10b981'};">${a11y.tapTargetIssues}</div></div>
            </div>
            ${a11yIssuesHtml}
          `;

          // =====================================
          // 4. فحص الأرشفة
          // =====================================
          const idx = response.indexability;
          const indexBadge = document.getElementById('index-badge');
          indexBadge.className = idx.isIndexable ? 'badge badge-green' : 'badge';
          indexBadge.innerText = idx.isIndexable ? 'مفهرسة ✅' : 'محظورة 🚫';

          let idxIssuesHtml = idx.issues.length > 0 ? `<div style="color:#ef4444; font-weight:bold; margin-top:10px; background:#fef2f2; padding:8px; border-radius:6px;">⚠️ مشاكل تمنع الأرشفة:<br> - ${idx.issues.join('<br> - ')}</div>` : '';
          document.getElementById('indexability-data').innerHTML = `
            <div class="list-item" style="direction:rtl;"><strong style="width:100px; color:#64748b;">Meta Robots:</strong> <span style="direction:ltr; flex:1; color:${idx.metaRobots.includes('noindex') ? 'red' : 'green'}; font-weight:bold;">${idx.metaRobots}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:100px; color:#64748b;">X-Robots-Tag:</strong> <span style="direction:ltr; flex:1;">${idx.xRobotsTag}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:100px; color:#64748b;">Robots.txt:</strong> <span style="flex:1; font-weight:bold;">${idx.robotsTxtStatus}</span></div>
            ${idxIssuesHtml}
          `;

          // =====================================
          // 5. اللغات والترجمة (Hreflang)
          // =====================================
          const hrefData = response.hreflangData;
          const hrefBadge = document.getElementById('hreflang-badge');
          hrefBadge.innerText = hrefData.exists ? `${hrefData.totalTags} لغات` : 'غير متوفر';
          hrefBadge.className = hrefData.exists && hrefData.issues.length === 0 ? 'badge badge-green' : 'badge';

          let hrefContent = "";
          if (hrefData.exists) {
            let tagsHtml = hrefData.tags.map(t => `<span class="tech-tag" style="background:#fef3c7; border-color:#e2e8f0;">${t.lang.toUpperCase()}</span>`).join(' ');
            let issuesHtml = hrefData.issues.length > 0 ? `<div style="color:#ef4444; font-size:11px; margin-top:8px;">${hrefData.issues.join('<br>')}</div>` : `<div style="color:#10b981; font-size:11px; margin-top:8px;">✅ إعداد اللغات سليم.</div>`;
            hrefContent = `<div style="margin-bottom:5px;"><strong style="font-size:12px; color:#64748b;">🌐 اللغات المتوفرة:</strong><br><div style="margin-top:5px;">${tagsHtml}</div></div>${issuesHtml}`;
          } else {
            hrefContent = `<div style="text-align:center; padding:10px; color:#64748b;">لا تستخدم هذه الصفحة وسوم Hreflang.</div>`;
          }
          document.getElementById('hreflang-data').innerHTML = hrefContent;

          // =====================================
          // 6. أداء جوجل والتقنيات الأساسية
          // =====================================
          let techTagsHtml = response.techStack.map(t => `<span class="tech-tag">${t}</span>`).join('');
          document.getElementById('tech-vitals-data').innerHTML = `
            <div style="margin-bottom:10px;"><strong style="color:#64748b; font-size:12px;">💻 التقنيات المكتشفة:</strong><br><div style="margin-top:5px;">${techTagsHtml}</div></div>
            <div class="metric-grid">
              <div class="metric-card"><div class="metric-title">سرعة العرض (LCP)</div><div class="metric-value" style="color: #2563eb;">${response.coreWebVitals.lcp}</div></div>
              <div class="metric-card"><div class="metric-title">ثبات العناصر (CLS)</div><div class="metric-value" style="color: #10b981;">${response.coreWebVitals.cls}</div></div>
            </div>
          `;

          // =====================================
          // 7. البيانات الأساسية والروابط 
          // =====================================
          const st = response.standardTags;
          document.getElementById('core-data').innerHTML = `
            <div class="list-item" style="direction:rtl;"><strong style="width:70px; color:#64748b;">العنوان:</strong> <span>${st.title}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:70px; color:#64748b;">الوصف:</strong> <span>${st.metaDescription}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:70px; color:#64748b;">Canonical:</strong> <span style="direction:ltr;">${st.canonical}</span></div>
            <div class="list-item" style="direction:rtl;"><strong style="width:70px; color:#64748b;">الخريطة:</strong> <span>${response.sitemap}</span></div>
          `;

          document.getElementById('headings-count').innerText = response.contentData.tree.length;
          document.getElementById('headings-data').innerHTML = response.contentData.tree.map(h => `<div class="list-item"><span class="tag-name">${h.tag}</span> <span style="flex:1;">${h.text || "فارغ"}</span></div>`).join('');
          
          document.getElementById('internal-count').innerText = response.linksData.internalLinks.length;
          document.getElementById('internal-links-data').innerHTML = response.linksData.internalLinks.map(link => `<div class="list-item">🔗 <a href="${link}" target="_blank" style="color:#2563eb; text-decoration:none; font-size:12px;">${link}</a></div>`).join('');
          
          document.getElementById('external-count').innerText = response.linksData.externalLinks.length;
          document.getElementById('external-links-data').innerHTML = response.linksData.externalLinks.map(link => `<div class="list-item">🚀 <a href="${link}" target="_blank" style="color:#ef4444; text-decoration:none; font-size:12px;">${link}</a></div>`).join('');
          
          document.getElementById('images-count').innerText = response.imagesData.total;
          document.getElementById('images-data').innerHTML = `<div style="text-align:center; padding:10px;">تحتاج تحسين: <strong style="color:red;">${response.imagesData.issuesCount}</strong> من أصل ${response.imagesData.total} صورة</div>` + response.imagesData.detailedIssues.map(img => `<div class="list-item" style="flex-direction:column; align-items:flex-start;"><div style="color:#64748b; font-size:11px; margin-bottom:5px; width:100%; word-break:break-all;">${img.src}</div><div style="display:flex; gap:5px; flex-wrap:wrap; direction:rtl; width:100%;"><span class="badge badge-orange">مشكلة</span></div></div>`).join('');

        }
      });
    } catch (error) { console.error(error); }
  });

  // =====================================
  // التصدير إلى Excel (SheetJS)
  // =====================================
  btnExport.addEventListener('click', () => {
    if (!currentReportData || typeof XLSX === 'undefined') {
        alert("تأكد من تحميل مكتبة xlsx.full.min.js واكتمال الفحص.");
        return;
    }
    const r = currentReportData;
    const wb = XLSX.utils.book_new();

    // 1. ورقة "نظرة عامة"
    const overviewData = [
      ["القسم", "المقياس", "النتيجة", "ملاحظات وتفاصيل"],
      ["الأساسيات", "عنوان الصفحة", r.standardTags.title, ""],
      ["الأساسيات", "الوصف (Meta)", r.standardTags.metaDescription, ""],
      ["الأساسيات", "الرابط القياسي", r.standardTags.canonical, ""],
      ["الأساسيات", "خريطة الموقع", r.sitemap, ""],
      ["المحتوى (NLP)", "نية البحث", r.textAnalysis.primaryIntent, ""],
      ["المحتوى (NLP)", "قابلية القراءة", r.textAnalysis.readability, ""],
      ["المحتوى (NLP)", "عدد الكلمات", r.textAnalysis.wordCount, ""],
      ["المحتوى (NLP)", "نسبة النص للكود", r.textAnalysis.ratio, ""],
      ["المحتوى (NLP)", "أهم الكلمات المفتاحية", r.textAnalysis.topKeywords.join(' - '), ""],
      ["الأداء والتقنية", "التقنيات", r.techStack.join(' - '), ""],
      ["الأداء والتقنية", "LCP", r.coreWebVitals.lcp, ""],
      ["الأداء والتقنية", "CLS", r.coreWebVitals.cls, ""],
      ["الأرشفة", "حالة الفهرسة", r.indexability.isIndexable ? "قابلة للأرشفة" : "محظورة", r.indexability.issues.join(' | ')],
      ["الأمان", "HSTS", r.securityHeaders.hsts.value, r.securityHeaders.hsts.description],
      ["الأمان", "X-Frame-Options", r.securityHeaders.xFrameOptions.value, r.securityHeaders.xFrameOptions.description],
      ["إمكانية الوصول", "أزرار اللمس الصغيرة", r.accessibility.tapTargetIssues, r.accessibility.issues.join(' | ')]
    ];
    const wsOverview = XLSX.utils.aoa_to_sheet(overviewData);
    // تجميد الصف الأول لسهولة القراءة
    wsOverview['!freeze'] = { xSplit: 0, ySplit: 1 };
    // توسيع الأعمدة
    wsOverview['!cols'] = [{wch: 15}, {wch: 25}, {wch: 50}, {wch: 40}];
    XLSX.utils.book_append_sheet(wb, wsOverview, "نظرة عامة");

    // 2. ورقة "شجرة العناوين"
    const headingsData = [["نوع العنوان", "النص"]];
    r.contentData.tree.forEach(h => headingsData.push([h.tag, h.text]));
    const wsHeadings = XLSX.utils.aoa_to_sheet(headingsData);
    wsHeadings['!cols'] = [{wch: 10}, {wch: 80}];
    XLSX.utils.book_append_sheet(wb, wsHeadings, "شجرة العناوين");

    // 3. ورقة "الروابط الداخلية"
    const internalLinksData = [["الرابط الداخلي"]];
    r.linksData.internalLinks.forEach(link => internalLinksData.push([link]));
    const wsInternal = XLSX.utils.aoa_to_sheet(internalLinksData);
    wsInternal['!cols'] = [{wch: 100}];
    XLSX.utils.book_append_sheet(wb, wsInternal, "الروابط الداخلية");

    // 4. ورقة "الروابط الخارجية"
    const externalLinksData = [["الرابط الخارجي"]];
    r.linksData.externalLinks.forEach(link => externalLinksData.push([link]));
    const wsExternal = XLSX.utils.aoa_to_sheet(externalLinksData);
    wsExternal['!cols'] = [{wch: 100}];
    XLSX.utils.book_append_sheet(wb, wsExternal, "الروابط الخارجية");

    // 5. ورقة "تحليل الصور"
    const imagesData = [["رابط الصورة", "وصف Alt", "ملاحظات ومشاكل الأداء"]];
    r.imagesData.detailedIssues.forEach(img => {
      let issuesStr = [];
      if(img.sizeWarning) issuesStr.push("تحتاج تغيير أبعادها");
      if(img.speedWarning) issuesStr.push("بطيئة التحميل");
      imagesData.push([img.src, img.alt, issuesStr.join(' + ')]);
    });
    const wsImages = XLSX.utils.aoa_to_sheet(imagesData);
    wsImages['!cols'] = [{wch: 60}, {wch: 30}, {wch: 40}];
    XLSX.utils.book_append_sheet(wb, wsImages, "تحليل الصور");

    // 6. ورقة "تعدد اللغات" (إن وجدت)
    if (r.hreflangData.exists) {
      const langData = [["كود اللغة", "الرابط البديل"]];
      r.hreflangData.tags.forEach(t => langData.push([t.lang, t.url]));
      if(r.hreflangData.issues.length > 0) {
          langData.push(["", ""]);
          langData.push(["مشاكل Hreflang المكتشفة", r.hreflangData.issues.join(' | ')]);
      }
      const wsLangs = XLSX.utils.aoa_to_sheet(langData);
      wsLangs['!cols'] = [{wch: 20}, {wch: 80}];
      XLSX.utils.book_append_sheet(wb, wsLangs, "تعدد اللغات");
    }

    // تنزيل الملف
    const fileName = `SEO_Report_${new URL(r.standardTags.canonical || window.location.href).hostname}.xlsx`;
    XLSX.writeFile(wb, fileName);
  });
});